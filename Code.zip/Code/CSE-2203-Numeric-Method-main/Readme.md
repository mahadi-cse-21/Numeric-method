pip install library_name
!pip install library_name